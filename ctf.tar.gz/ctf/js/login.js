function addTerminalLine(str, initDelay) {
    var span = $('<span></span>').addClass('tk-ocr-a-std terminal-content-line');
    var child = null;
    var childValue = "";
    var childClass = 'terminal-content-line-letter';
    var delay = initDelay;
    if(str.indexOf('>') == 0) span.addClass('blue');
  
    for (var i = 0; i < str.length; i++) {
      childValue = str.charAt(i);
      
      if(childValue != " ") delay += 0.0125;
      
      child = $("<span></span>").addClass(childClass).text(childValue);
      span.append(child);
      TweenMax.set(child.get(), {opacity: 0 });
      TweenMax.to(child.get(),  0.035, {opacity: 1, delay: delay});
    }
    $('.terminal-content').append(span);
    return delay;
  }
  
  function checkInput() {
    var totalDelay = 0;
    var lines = $('.terminal-input').val().split("\n");
    for (var i = 0; i < lines.length; i++) {
      totalDelay = addTerminalLine(lines[i], totalDelay);
    }
  
    $('.terminal-input').val('');
  }
  
  $('.terminal-input').keydown(function (e){
      if(e.keyCode == 13){
        checkInput();
      }
  });
  
  checkInput();